INSERT INTO `categories` (`id`, `name_vi`, `name_en`, `type`, `parent_id`, `order`, `created_at`, `updated_at`)
VALUES
	(1,'Danh Muc','Categories','gid',0,0,'2019-10-29 15:28:26','2019-10-29 16:40:38'),
	(2,'Van Phong','Office Building','gid',1,0,'2019-10-29 15:32:43','2019-10-29 16:40:55'),
	(3,'Product Design','Thiet ke san pham','gid',0,0,'2019-10-30 12:23:13','2019-10-30 14:52:43'),
	(4,'Coffee House','Coffee House','gid',1,0,'2019-10-30 14:53:21','2019-10-30 14:53:21'),
	(5,'Home Decor','Home Decor','gid',1,0,'2019-10-30 14:53:39','2019-10-30 14:53:39'),
	(6,'Chair Design','Chair Design','gid',3,0,'2019-10-30 14:53:55','2019-10-30 14:53:55'),
	(7,'Table Design','Table Design','gid',3,0,'2019-10-30 14:54:10','2019-10-30 14:54:10'),
	(8,'Set Design','Set Design','gid',3,0,'2019-10-30 14:54:21','2019-10-30 14:54:21');

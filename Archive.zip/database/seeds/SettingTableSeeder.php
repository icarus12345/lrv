<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class SettingTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        DB::table('settings')->insert([
            'name' => 'flat_rate',
            'value' => 150000,
        ]);
        DB::table('settings')->insert([
            'name' => 'tax',
            'value' => 10,
        ]);
    }
}
